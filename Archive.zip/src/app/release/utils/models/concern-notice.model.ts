export interface FindFirmWare {
    wersConcerns ?: string,
    wersNotice ?: string
}

export class FirmWareReport {
    firmWareReportTitle : string = "";
}