export class AddSblModel {
    release_type : string = "new_sbl";
    supplier : string = "";
    module_type : string = "";
    micro_type : string = "";
    description : string = "";
    lead_my_program : string = "";
    current_part_number : string = "";
}