export class AddPartIIModel {
    release_type : string = "part_II";
    module_type : string = "";
    micro_type : string = "";
    ggds_version : string = "";
    swdl_version : string = "";
    part_number : string = "";
    description : string = "";
    v_sem : string = "";
}