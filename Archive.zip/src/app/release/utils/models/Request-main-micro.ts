export class AddRequestMainMicroModel {
    supplier : string = "select_supplier";
    module_type : string = "Select_Module_type";
    micro_type: string =""
   
}