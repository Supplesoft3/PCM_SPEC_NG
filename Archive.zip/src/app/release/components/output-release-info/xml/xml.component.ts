import { Component } from '@angular/core';

@Component({
  selector: 'app-xml',
  templateUrl: './xml.component.html',
  styleUrl: './xml.component.scss'
})
export class XmlComponent {

}
