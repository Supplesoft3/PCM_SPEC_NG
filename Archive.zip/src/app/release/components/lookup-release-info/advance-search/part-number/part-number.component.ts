import { Component } from '@angular/core';

@Component({
  selector: 'app-part-number',
  templateUrl: './part-number.component.html',
  styleUrl: './part-number.component.scss'
})
export class PartNumberComponent {

}
