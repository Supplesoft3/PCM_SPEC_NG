import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier-calibration-download',
  templateUrl: './supplier-calibration-download.component.html',
  styleUrl: './supplier-calibration-download.component.scss'
})
export class SupplierCalibrationDownloadComponent {

}
