import { Component } from '@angular/core';

@Component({
  selector: 'app-reset-soft-lock',
  templateUrl: './reset-soft-lock.component.html',
  styleUrl: './reset-soft-lock.component.scss'
})
export class ResetSoftLockComponent {

}
