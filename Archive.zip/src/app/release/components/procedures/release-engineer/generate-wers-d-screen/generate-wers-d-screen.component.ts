import { Component } from '@angular/core';

@Component({
  selector: 'app-generate-wers-d-screen',
  templateUrl: './generate-wers-d-screen.component.html',
  styleUrl: './generate-wers-d-screen.component.scss'
})
export class GenerateWersDScreenComponent {

}
