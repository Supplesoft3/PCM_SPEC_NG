import { Component } from '@angular/core';

@Component({
  selector: 'app-release-engineer',
  templateUrl: './release-engineer.component.html',
  styleUrl: './release-engineer.component.scss'
})
export class ReleaseEngineerComponent {

}
