import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HcrRoutingModule } from './hcr-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HcrRoutingModule
  ]
})
export class HcrModule { }
